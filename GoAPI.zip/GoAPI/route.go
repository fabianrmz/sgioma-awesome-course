package main

import (
	"encoding/json"
	"fmt"
	"net/http"

	"github.com/ericktec/apiRest/entity"

	"github.com/ericktec/apiRest/repository"
)

var (
	repo repository.SongRepository = repository.NewSongRepository()
)

func getSongs(res http.ResponseWriter, req *http.Request) {

	res.Header().Set("Content-type", "application/json")
	songs, errRepo := repo.FindAll()
	if errRepo != nil {
		res.WriteHeader(http.StatusInternalServerError)
		res.Write([]byte(`{"error": "Error getting the songs from Firestore"}`))
		return
	}

	res.WriteHeader(http.StatusOK)
	json.NewEncoder(res).Encode(songs)

}

func addSong(res http.ResponseWriter, req *http.Request) {
	res.Header().Set("Content-type", "application/json")
	var song entity.Song
	err := json.NewDecoder(req.Body).Decode(&song)

	if err != nil {
		res.WriteHeader(http.StatusInternalServerError)
		res.Write([]byte(`{"error": "Error unmarshalling the songs array"}`))
		return
	}
	repo.Save(&song)
	res.WriteHeader(http.StatusCreated)
	json.NewEncoder(res).Encode(song)
}

func patchSongMethod(res http.ResponseWriter, req *http.Request) {
	res.Header().Set("Content-type", "application/json")
	req.ParseForm()
	err := repo.UpdatePatch(req.FormValue("id"), req.FormValue("title"))
	if err != nil {
		res.WriteHeader(http.StatusInternalServerError)
		res.Write([]byte(`{"error": "Error updating the document in database"}`))
		return
	}
	res.WriteHeader(http.StatusCreated)
	res.Write([]byte(`{"title": ` + req.FormValue("title") + `}`))
}

func putSongMethod(res http.ResponseWriter, req *http.Request) {
	res.Header().Set("Content-type", "application/json")
	res.WriteHeader(http.StatusCreated)
	res.Write([]byte(`{"status": "sucess this the put method managed by golang backend" }`))
}

func deleteSongMethod(res http.ResponseWriter, req *http.Request) {
	res.Header().Set("Content-type", "application/json")
	
	fmt.Println("test " + req.FormValue("id"))
	err := repo.DeleteSong(req.FormValue("id"))
	if err != nil {
		res.WriteHeader(http.StatusInternalServerError)
		res.Write([]byte(`{"error": "Error deleting the document in database"}`))
		return
	}
	res.WriteHeader(http.StatusOK)
	res.Write([]byte(`{"Status": "The song was removed successfully"}`))

}

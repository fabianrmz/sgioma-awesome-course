package main

import (
	"fmt"
	"log"
	"net/http"

	"github.com/gorilla/mux"
)

//$env:GOOGLE_APPLICATION_CREDENTIALS="C:\Users\Erick\Desktop\ajax-master\GoAPI\webclass-97686-firebase-adminsdk-sceku-3696ca9353.json"

func main() {
	router := mux.NewRouter()
	const port string = ":8000"
	router.HandleFunc("/", func(res http.ResponseWriter, req *http.Request) {
		fmt.Println(res, "Up and running")
	})

	router.HandleFunc("/songs", getSongs).Methods("GET")
	router.HandleFunc("/songs", addSong).Methods("POST")
	router.HandleFunc("/songs", patchSongMethod).Methods("PATCH")
	router.HandleFunc("/songs", putSongMethod).Methods("PUT")
	router.HandleFunc("/songs", deleteSongMethod).Methods("DELETE")

	log.Println("Server listening on port ", port)
	log.Fatalln(http.ListenAndServe(port, router))

}

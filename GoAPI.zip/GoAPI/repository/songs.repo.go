package repository

import (
	"context"
	"log"

	"cloud.google.com/go/firestore"
	"github.com/ericktec/apiRest/entity"
	"google.golang.org/api/iterator"
)

type SongRepository interface {
	Save(song *entity.Song) (*entity.Song, error)
	FindAll() ([]entity.Song, error)
	UpdatePatch(id string, title string) error
	DeleteSong(id string) error
}

type repo struct{}

func NewSongRepository() SongRepository {
	return &repo{}
}

const (
	projectId      string = "webclass-97686"
	collectionName string = "songs"
)

func (*repo) Save(song *entity.Song) (*entity.Song, error) {
	ctx := context.Background()
	client, err := firestore.NewClient(ctx, projectId)
	if err != nil {
		log.Fatalf("Failed to create a Firestore Client: %v", err)
		return nil, err
	}

	defer client.Close()

	_, _, err2 := client.Collection(collectionName).Add(ctx, map[string]interface{}{
		"title":  song.Title,
		"image":  song.Image,
		"author": song.Author,
	})

	if err2 != nil {
		log.Fatalf("Failed adding a new song: %v", err)
	}

	return song, nil

}

func (*repo) FindAll() ([]entity.Song, error) {
	ctx := context.Background()
	client, err := firestore.NewClient(ctx, projectId)
	if err != nil {
		log.Fatalf("Failed to create a Firestore Client: %v", err)
		return nil, err
	}

	defer client.Close()

	var songs []entity.Song
	iter := client.Collection(collectionName).Documents(ctx)
	for {
		doc, err := iter.Next()

		if err == iterator.Done {
			break
		}

		if err != nil {
			log.Fatalf("Failed to iterate the list of songs : %v ", err)
			return nil, err
		}
		song := entity.Song{
			Title:  doc.Data()["title"].(string),
			Image:  doc.Data()["image"].(string),
			Author: doc.Data()["author"].(string),
		}
		songs = append(songs, song)

	}

	return songs, nil

}

func (*repo) UpdatePatch(id string, title string) error {
	ctx := context.Background()
	client, err := firestore.NewClient(ctx, projectId)
	if err != nil {
		log.Fatalf("Failed to create a Firestore Client: %v", err)
		return err
	}

	_, err = client.Collection(collectionName).Doc(id).Update(ctx, []firestore.Update{
		{
			Path:  "title",
			Value: title,
		},
	})
	if err != nil {
		// Handle any errors in an appropriate way, such as returning them.
		log.Printf("An error has occurred: %s", err)
	}

	defer client.Close()

	return nil

}

func (*repo) DeleteSong(id string) error {
	ctx := context.Background()
	client, err := firestore.NewClient(ctx, projectId)
	if err != nil {
		log.Fatalf("Failed to create a Firestore Client: %v", err)
		return err
	}

	_, err2 := client.Collection(collectionName).Doc(id).Delete(ctx)
	if err2 != nil {

		return err2
	}
	return nil
}

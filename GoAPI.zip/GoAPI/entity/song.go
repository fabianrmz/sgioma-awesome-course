package entity

type Song struct {
	Title  string `json:"title"`
	Author string `json:"author"`
	Image  string `json:"image"`
}
